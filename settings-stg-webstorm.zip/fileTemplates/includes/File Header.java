/**
 *  This class is not yet documented 
 *
 * User: Maros Urbanec
 * Date: ${DATE}
 * Time: ${TIME}
 */
